#!/usr/bin/env python3
"""Verify the locked CatBoost model results reported for the 2021-2024 final test set."""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    roc_auc_score,
)

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "PRIMARY_Model_Dataset_WUENIC_WDI_2002_2024.csv"
MODEL = ROOT / "model" / "final_catboost_backsliding_model.joblib"


def risk_capture(y_true: np.ndarray, p: np.ndarray, fraction: float) -> float:
    n = int(round(fraction * len(y_true)))
    idx = np.argsort(-p)[:n]
    return float(y_true[idx].sum() / y_true.sum())


def main() -> None:
    df = pd.read_csv(DATA)
    bundle = joblib.load(MODEL)
    test = df.loc[df["year"].between(2021, 2024)].copy()

    X = test[bundle["features"]]
    X_imp = bundle["imputer"].transform(X)
    raw_p = bundle["model"].predict_proba(X_imp)[:, 1]
    raw_p = np.clip(raw_p, 1e-6, 1 - 1e-6)
    logits = np.log(raw_p / (1 - raw_p)).reshape(-1, 1)
    calibrated_p = bundle["calibrator"].predict_proba(logits)[:, 1]

    y = test["backslide_5pp"].astype(int).to_numpy()
    threshold = float(bundle["classification_threshold"])
    pred = (calibrated_p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred).ravel()

    metrics = {
        "n": len(y),
        "events": int(y.sum()),
        "prevalence": float(y.mean()),
        "auroc": float(roc_auc_score(y, calibrated_p)),
        "auprc": float(average_precision_score(y, calibrated_p)),
        "brier": float(brier_score_loss(y, calibrated_p)),
        "threshold": threshold,
        "sensitivity": float(tp / (tp + fn)),
        "specificity": float(tn / (tn + fp)),
        "precision": float(precision_score(y, pred)),
        "f1": float(f1_score(y, pred)),
        "recall_top10pct": risk_capture(y, calibrated_p, 0.10),
        "recall_top20pct": risk_capture(y, calibrated_p, 0.20),
    }

    for key, value in metrics.items():
        print(f"{key}: {value}")

    expected = {
        "n": 780,
        "events": 65,
        "auroc": 0.702786444324906,
        "auprc": 0.20732311494854244,
        "brier": 0.07282516739030727,
        "sensitivity": 0.5230769230769231,
        "specificity": 0.7356643356643356,
        "precision": 0.15246636771300448,
        "f1": 0.2361111111111111,
        "recall_top10pct": 0.2923076923076923,
        "recall_top20pct": 0.36923076923076925,
    }
    for key, exp in expected.items():
        got = metrics[key]
        if isinstance(exp, int):
            assert got == exp, f"{key}: expected {exp}, got {got}"
        else:
            assert np.isclose(got, exp, rtol=0, atol=1e-12), f"{key}: expected {exp}, got {got}"

    print("\nPASS: locked final-test metrics reproduce the reported values.")


if __name__ == "__main__":
    main()
