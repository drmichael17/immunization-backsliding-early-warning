#!/usr/bin/env python3
"""
Build the core WUENIC country-year dataset for:

Predicting Childhood Immunization Backsliding Before It Occurs:
A Global Machine-Learning Early-Warning Study

Official source:
UNICEF SDMX API / GLOBAL_DATAFLOW
Core indicators:
    IM_DTP1, IM_DTP3, IM_MCV1, IM_BCG, IM_POL3

Outputs (written next to this script):
    WUENIC_core_2000_2025.csv
    WUENIC_model_ready_2002_2024.csv
    WUENIC_core_summary.json
    WUENIC_iso3_review.csv

Python 3 standard library only. No pandas required.
"""

from __future__ import annotations

import csv
import io
import json
import math
import statistics
import sys
import time
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path

BASE = "https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/UNICEF,GLOBAL_DATAFLOW,1.0"
INDICATORS = {
    "IM_DTP1": "dtp1",
    "IM_DTP3": "dtp3",
    "IM_MCV1": "mcv1",
    "IM_BCG": "bcg",
    "IM_POL3": "pol3",
}
START_YEAR = 2000
END_YEAR = 2025
OUTDIR = Path(__file__).resolve().parent
SOURCE_VINTAGE = "WUENIC 2025 revision / released Jul 2026"

# Common aggregate codes that can appear in broad SDMX flows.
# The script additionally writes an ISO3 review file so the final 195-country
# analytic universe can be explicitly checked before modelling.
KNOWN_AGGREGATES = {
    "WLD", "GLB", "SSA", "LAC", "EAP", "ECA", "MNA", "SAS", "ECS",
    "NAC", "HIC", "LIC", "LMC", "UMC", "LMY", "MIC", "OED",
}


def fetch_text(url: str, retries: int = 4, timeout: int = 90) -> str:
    headers = {
        "User-Agent": "Mozilla/5.0 WUENIC-public-health-research/1.0",
        "Accept": "text/csv,application/csv,text/plain,*/*",
    }
    last_exc = None
    for attempt in range(retries):
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8-sig")
        except Exception as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
    raise RuntimeError(f"Failed to retrieve {url}: {last_exc}")


def norm(value) -> str:
    return "" if value is None else str(value).strip()


def choose_col(fieldnames, candidates):
    if not fieldnames:
        return None
    exact = {f.upper(): f for f in fieldnames}
    for cand in candidates:
        if cand.upper() in exact:
            return exact[cand.upper()]
    for f in fieldnames:
        up = f.upper()
        for cand in candidates:
            c = cand.upper()
            if up.startswith(c + ":") or up.endswith(":" + c):
                return f
    return None


def to_float(value):
    s = norm(value)
    if not s:
        return None
    try:
        x = float(s)
    except ValueError:
        return None
    return x if math.isfinite(x) else None


def is_country_like(code: str) -> bool:
    code = norm(code).upper()
    return len(code) == 3 and code.isalpha() and code not in KNOWN_AGGREGATES


def fetch_indicator(indicator: str):
    # Fetch indicators separately: easier to audit and each response is small.
    key = f".{indicator}."
    params = urllib.parse.urlencode({
        "format": "csv",
        "labels": "id",
        "startPeriod": START_YEAR,
        "endPeriod": END_YEAR,
        "count": 20000,
        "startIndex": 0,
    })
    url = f"{BASE}/{key}?{params}"
    print(f"Fetching {indicator} ...", file=sys.stderr)
    text = fetch_text(url)
    reader = csv.DictReader(io.StringIO(text))
    fields = reader.fieldnames or []

    area_col = choose_col(fields, ["REF_AREA", "GEOGRAPHIC_AREA", "LOCATION"])
    time_col = choose_col(fields, ["TIME_PERIOD", "TIME", "YEAR"])
    value_col = choose_col(fields, ["OBS_VALUE", "VALUE"])
    sex_col = choose_col(fields, ["SEX"])
    ind_col = choose_col(fields, ["INDICATOR"])

    if not area_col or not time_col or not value_col:
        raise RuntimeError(
            f"Could not identify required columns for {indicator}. "
            f"Returned columns: {fields}"
        )

    dedup = {}
    conflicts = []
    for row in reader:
        if ind_col and norm(row.get(ind_col)) and norm(row.get(ind_col)) != indicator:
            continue

        # Immunization indicators are generally total-population measures.
        if sex_col:
            sex = norm(row.get(sex_col)).upper()
            if sex not in {"", "_T", "T", "TOTAL", "BTSX", "BOTH"}:
                continue

        iso3 = norm(row.get(area_col)).upper()
        if not is_country_like(iso3):
            continue

        try:
            year = int(float(norm(row.get(time_col))))
        except ValueError:
            continue
        if not START_YEAR <= year <= END_YEAR:
            continue

        value = to_float(row.get(value_col))
        if value is None or not 0 <= value <= 100:
            continue

        key2 = (iso3, year)
        if key2 in dedup and abs(dedup[key2] - value) > 1e-9:
            conflicts.append((iso3, year, dedup[key2], value))
        else:
            dedup[key2] = value

    if conflicts:
        raise RuntimeError(
            f"{indicator}: conflicting duplicate country-year observations. "
            f"Audit remaining SDMX dimensions. Sample: {conflicts[:10]}"
        )

    print(f"  retained {len(dedup):,} country-year values", file=sys.stderr)
    return dedup


def fmt(x):
    if x is None:
        return ""
    if isinstance(x, int):
        return x
    return round(float(x), 6)


def main():
    series = {indicator: fetch_indicator(indicator) for indicator in INDICATORS}
    all_keys = sorted(set().union(*(d.keys() for d in series.values())))

    core = {}
    for iso3, year in all_keys:
        rec = {
            "iso3": iso3,
            "country": iso3,  # ISO3 is the merge key; names can be added from metadata later.
            "year": year,
            "source_vintage": SOURCE_VINTAGE,
        }
        for indicator, short in INDICATORS.items():
            rec[short] = series[indicator].get((iso3, year))
        # DTP3 is central to the outcome; retain rows where it exists.
        if rec["dtp3"] is not None:
            core[(iso3, year)] = rec

    core_fields = [
        "iso3", "country", "year", "dtp1", "dtp3", "mcv1", "bcg", "pol3",
        "source_vintage"
    ]
    core_path = OUTDIR / "WUENIC_core_2000_2025.csv"
    with core_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=core_fields)
        w.writeheader()
        for key in sorted(core):
            rec = core[key]
            w.writerow({field: fmt(rec.get(field)) for field in core_fields})

    by_country = defaultdict(dict)
    for (iso3, year), rec in core.items():
        by_country[iso3][year] = rec

    model_rows = []
    for iso3 in sorted(by_country):
        years = by_country[iso3]
        for year in sorted(years):
            r = years[year]
            dtp1, dtp3, mcv1 = r.get("dtp1"), r.get("dtp3"), r.get("mcv1")
            lag1, lag2, lead1 = years.get(year - 1), years.get(year - 2), years.get(year + 1)

            def cv(rec, var):
                return None if rec is None else rec.get(var)

            dtp_dropout = None
            if dtp1 not in (None, 0) and dtp3 is not None:
                dtp_dropout = (dtp1 - dtp3) / dtp1 * 100.0

            zero_dose_proxy = None if dtp1 is None else 100.0 - dtp1
            dtp_mcv_gap = None if dtp3 is None or mcv1 is None else dtp3 - mcv1

            dtp3_change_1y = None
            if lag1 is not None and cv(lag1, "dtp3") is not None:
                dtp3_change_1y = dtp3 - cv(lag1, "dtp3")

            dtp3_change_2y = dtp3_slope_3y = dtp3_sd_3y = None
            dtp1_slope_3y = mcv1_slope_3y = None
            if lag2 is not None:
                lag2_dtp3 = cv(lag2, "dtp3")
                if lag2_dtp3 is not None:
                    dtp3_change_2y = dtp3 - lag2_dtp3
                    dtp3_slope_3y = dtp3_change_2y / 2.0

                vals3 = [cv(lag2, "dtp3"), cv(lag1, "dtp3"), dtp3]
                if all(x is not None for x in vals3):
                    dtp3_sd_3y = statistics.stdev(vals3)

                lag2_dtp1 = cv(lag2, "dtp1")
                if lag2_dtp1 is not None and dtp1 is not None:
                    dtp1_slope_3y = (dtp1 - lag2_dtp1) / 2.0

                lag2_mcv1 = cv(lag2, "mcv1")
                if lag2_mcv1 is not None and mcv1 is not None:
                    mcv1_slope_3y = (mcv1 - lag2_mcv1) / 2.0

            dtp3_next_year = cv(lead1, "dtp3")
            dtp3_change_next_year = None
            if dtp3_next_year is not None:
                dtp3_change_next_year = dtp3_next_year - dtp3

            def backslide(threshold):
                if dtp3_change_next_year is None:
                    return None
                return int(dtp3_change_next_year <= -threshold)

            model_rows.append({
                "iso3": iso3,
                "country": r.get("country") or iso3,
                "year": year,
                "dtp1": dtp1,
                "dtp3": dtp3,
                "mcv1": mcv1,
                "bcg": r.get("bcg"),
                "pol3": r.get("pol3"),
                "dtp_dropout": dtp_dropout,
                "zero_dose_proxy": zero_dose_proxy,
                "dtp_mcv_gap": dtp_mcv_gap,
                "dtp3_change_1y": dtp3_change_1y,
                "dtp3_change_2y": dtp3_change_2y,
                "dtp3_slope_3y": dtp3_slope_3y,
                "dtp3_sd_3y": dtp3_sd_3y,
                "dtp1_slope_3y": dtp1_slope_3y,
                "mcv1_slope_3y": mcv1_slope_3y,
                "dtp3_next_year": dtp3_next_year,
                "dtp3_change_next_year": dtp3_change_next_year,
                "backslide_3pp": backslide(3),
                "backslide_5pp": backslide(5),
                "backslide_10pp": backslide(10),
                "eligible_primary": int(
                    dtp3_next_year is not None and dtp3_slope_3y is not None
                ),
            })

    model_fields = [
        "iso3", "country", "year", "dtp1", "dtp3", "mcv1", "bcg", "pol3",
        "dtp_dropout", "zero_dose_proxy", "dtp_mcv_gap", "dtp3_change_1y",
        "dtp3_change_2y", "dtp3_slope_3y", "dtp3_sd_3y", "dtp1_slope_3y",
        "mcv1_slope_3y", "dtp3_next_year", "dtp3_change_next_year",
        "backslide_3pp", "backslide_5pp", "backslide_10pp", "eligible_primary"
    ]
    model_path = OUTDIR / "WUENIC_model_ready_2002_2024.csv"
    with model_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=model_fields)
        w.writeheader()
        for row in model_rows:
            if 2002 <= row["year"] <= 2024:
                w.writerow({field: fmt(row.get(field)) for field in model_fields})

    # Explicit geographic-code audit file.
    iso_path = OUTDIR / "WUENIC_iso3_review.csv"
    with iso_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["iso3", "first_year", "last_year", "n_years", "review_status"])
        for iso3 in sorted(by_country):
            ys = sorted(by_country[iso3])
            w.writerow([iso3, min(ys), max(ys), len(ys), "REVIEW"])

    raw_n = len(core)
    eligible = [r for r in model_rows if r["eligible_primary"] == 1]

    def event_stats(field):
        vals = [r[field] for r in model_rows if r.get(field) is not None]
        events = sum(v == 1 for v in vals)
        return {
            "events": events,
            "eligible_n": len(vals),
            "prevalence": (events / len(vals)) if vals else None,
        }

    missing = {}
    for var in ["dtp1", "dtp3", "mcv1", "bcg", "pol3"]:
        observed = sum(rec.get(var) is not None for rec in core.values())
        missing[var] = {
            "observed_n": observed,
            "missing_n": raw_n - observed,
            "missing_pct": ((raw_n - observed) / raw_n) if raw_n else None,
        }

    summary = {
        "source": "UNICEF SDMX GLOBAL_DATAFLOW / immunization series",
        "requested_period": [START_YEAR, END_YEAR],
        "source_vintage_note": SOURCE_VINTAGE,
        "raw_country_year_rows_with_dtp3": raw_n,
        "unique_iso3_codes_before_final_195-country_audit": len(by_country),
        "eligible_primary_country_years": len(eligible),
        "event_prevalence": {
            "backslide_3pp": event_stats("backslide_3pp"),
            "backslide_5pp": event_stats("backslide_5pp"),
            "backslide_10pp": event_stats("backslide_10pp"),
        },
        "raw_missingness": missing,
        "required_manual_qc": (
            "Review WUENIC_iso3_review.csv against the official 195-country WUENIC "
            "universe before final analysis; remove any residual aggregate codes."
        ),
    }
    summary_path = OUTDIR / "WUENIC_core_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\nBuild complete")
    print(f"Core CSV:        {core_path}")
    print(f"Model-ready CSV: {model_path}")
    print(f"ISO3 review:     {iso_path}")
    print(f"Summary JSON:    {summary_path}")
    print(json.dumps(summary["event_prevalence"], indent=2))


if __name__ == "__main__":
    main()
