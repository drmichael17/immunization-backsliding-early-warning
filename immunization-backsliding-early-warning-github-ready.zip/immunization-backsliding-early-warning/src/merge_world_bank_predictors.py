#!/usr/bin/env python3
"""
Merge prespecified World Bank WDI structural predictors onto the model-ready
WUENIC immunization-backsliding country-year dataset.

PRIMARY DESIGN RULE:
For a WUENIC predictor year t, World Bank predictors are merged from year t-1
to reduce look-ahead/publication-timing risk.

Official World Bank API:
https://api.worldbank.org/v2/
No API key is required.

Input:
  WUENIC_Backsliding_Model_Ready_2002_2024.csv

Outputs:
  WorldBank_WDI_Raw_Long_2000_2024.csv
  WorldBank_WDI_Wide_2000_2024.csv
  WUENIC_WorldBank_Merged_Model_Ready.csv
  WorldBank_Merge_Missingness.csv
  WorldBank_Merge_Summary.json
"""

from __future__ import annotations
import csv
import json
import math
import time
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone

INPUT = Path("WUENIC_Backsliding_Model_Ready_2002_2024.csv")
OUTDIR = Path(".")

INDICATORS = {
    "NY.GDP.PCAP.KD": "wb_gdp_pc_const2015_lag1",
    "SH.XPD.CHEX.GD.ZS": "wb_health_exp_gdp_lag1",
    "SH.XPD.OOPC.CH.ZS": "wb_oop_share_lag1",
    "SP.DYN.TFRT.IN": "wb_fertility_lag1",
    "SP.URB.TOTL.IN.ZS": "wb_urban_pct_lag1",
    "SP.POP.0014.TO.ZS": "wb_age0_14_pct_lag1",
    "SH.DYN.MORT": "wb_u5_mortality_lag1",
}

# Fetch a little wider than needed for auditability. Primary merge uses t-1,
# so model years 2002–2024 consume WB years 2001–2023.
WB_START = 2000
WB_END = 2024

def get_json(url: str, retries: int = 5, timeout: int = 90):
    headers = {
        "User-Agent": "WUENIC-immunization-backsliding-study/1.0",
        "Accept": "application/json",
    }
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            last = exc
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
    raise RuntimeError(f"Failed after {retries} attempts: {url}\n{last}")

def fetch_indicator(code: str):
    # World Bank V2 API returns [metadata, observations].
    # One request is normally enough with a high per_page limit.
    params = urllib.parse.urlencode({
        "format": "json",
        "per_page": 40000,
        "date": f"{WB_START}:{WB_END}",
    })
    url = f"https://api.worldbank.org/v2/country/all/indicator/{code}?{params}"
    payload = get_json(url)
    if not isinstance(payload, list) or len(payload) < 2:
        raise RuntimeError(f"Unexpected World Bank response for {code}: {type(payload)}")
    return payload[1] or []

def to_float(x):
    if x in (None, ""):
        return None
    try:
        y = float(x)
        return y if math.isfinite(y) else None
    except Exception:
        return None

def read_wuenic(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path: Path, rows, fields):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})

def main():
    if not INPUT.exists():
        raise FileNotFoundError(
            f"{INPUT} not found. Put this script in the same folder as the "
            "model-ready WUENIC CSV, or edit INPUT at the top of the script."
        )

    wuenic = read_wuenic(INPUT)
    iso3_set = {r["iso3c"].strip().upper() for r in wuenic}
    if len(iso3_set) != 195:
        print(f"Warning: found {len(iso3_set)} ISO3 codes in WUENIC input, expected 195.")

    raw_long = []
    wb = defaultdict(dict)  # (iso3, year) -> {shortvar: value}

    for code, shortvar in INDICATORS.items():
        print(f"Fetching {code} ...")
        obs = fetch_indicator(code)
        kept = 0
        for item in obs:
            iso3 = (item.get("countryiso3code") or "").strip().upper()
            if iso3 not in iso3_set:
                continue
            try:
                year = int(item.get("date"))
            except Exception:
                continue
            if not (WB_START <= year <= WB_END):
                continue
            value = to_float(item.get("value"))
            raw_long.append({
                "iso3c": iso3,
                "year": year,
                "indicator_code": code,
                "indicator_name": item.get("indicator", {}).get("value", ""),
                "value": "" if value is None else value,
                "source_url": f"https://api.worldbank.org/v2/country/{iso3}/indicator/{code}",
            })
            if value is not None:
                key = (iso3, year)
                if shortvar in wb[key] and wb[key][shortvar] != value:
                    raise RuntimeError(f"Conflicting duplicate value for {iso3} {year} {code}")
                wb[key][shortvar] = value
                kept += 1
        print(f"  non-missing country-year values kept: {kept:,}")

    # Write raw-long and wide World Bank extracts.
    raw_fields = ["iso3c","year","indicator_code","indicator_name","value","source_url"]
    write_csv(OUTDIR / "WorldBank_WDI_Raw_Long_2000_2024.csv", raw_long, raw_fields)

    wide_fields = ["iso3c","year"] + list(INDICATORS.values())
    wide_rows = []
    for (iso3, year) in sorted(wb):
        rec = {"iso3c": iso3, "year": year}
        rec.update(wb[(iso3, year)])
        wide_rows.append(rec)
    write_csv(OUTDIR / "WorldBank_WDI_Wide_2000_2024.csv", wide_rows, wide_fields)

    # Lag-1 merge.
    merged = []
    for r in wuenic:
        iso3 = r["iso3c"].strip().upper()
        t = int(float(r["year"]))
        wb_year = t - 1
        out = dict(r)
        out["wb_predictor_year"] = wb_year
        vals = wb.get((iso3, wb_year), {})
        for shortvar in INDICATORS.values():
            out[shortvar] = vals.get(shortvar, "")
        merged.append(out)

    merged_fields = list(wuenic[0].keys()) + ["wb_predictor_year"] + list(INDICATORS.values())
    write_csv(OUTDIR / "WUENIC_WorldBank_Merged_Model_Ready.csv", merged, merged_fields)

    # Missingness by variable and a strict complete-case count.
    miss_rows = []
    for code, shortvar in INDICATORS.items():
        nonmissing = sum(r.get(shortvar, "") not in ("", None) for r in merged)
        n = len(merged)
        miss_rows.append({
            "indicator_code": code,
            "merged_column": shortvar,
            "n_total": n,
            "n_nonmissing": nonmissing,
            "n_missing": n - nonmissing,
            "missing_pct": (n - nonmissing) / n if n else None,
        })
    write_csv(
        OUTDIR / "WorldBank_Merge_Missingness.csv",
        miss_rows,
        ["indicator_code","merged_column","n_total","n_nonmissing","n_missing","missing_pct"],
    )

    strict_cc = sum(
        all(r.get(shortvar, "") not in ("", None) for shortvar in INDICATORS.values())
        for r in merged
    )

    summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "wuenic_rows": len(wuenic),
        "unique_wuenic_countries": len(iso3_set),
        "lag_rule": "World Bank year = WUENIC predictor year - 1",
        "world_bank_requested_period": [WB_START, WB_END],
        "indicators": INDICATORS,
        "strict_complete_case_rows_all_7_wb_predictors": strict_cc,
        "strict_complete_case_pct": strict_cc / len(merged) if merged else None,
        "missingness": miss_rows,
        "primary_source": "https://api.worldbank.org/v2/",
        "note": (
            "Do not automatically use strict complete-case analysis. Review variable-specific "
            "missingness first; prespecify imputation within training folds where appropriate."
        ),
    }
    (OUTDIR / "WorldBank_Merge_Summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    print("\nDone.")
    print(f"Merged rows: {len(merged):,}")
    print(f"Strict complete cases across all seven WDI predictors: {strict_cc:,}")
    print("Missingness:")
    for r in miss_rows:
        print(f"  {r['indicator_code']}: {r['missing_pct']:.1%}")

if __name__ == "__main__":
    main()
