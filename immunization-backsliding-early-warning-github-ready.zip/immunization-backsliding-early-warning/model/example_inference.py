import joblib
import numpy as np
import pandas as pd

bundle = joblib.load("final_catboost_backsliding_model.joblib")

def predict_backsliding(input_df: pd.DataFrame) -> pd.DataFrame:
    X = input_df[bundle["features"]]
    X_imp = bundle["imputer"].transform(X)

    raw_p = bundle["model"].predict_proba(X_imp)[:, 1]
    raw_p = np.clip(raw_p, 1e-6, 1 - 1e-6)

    logits = np.log(raw_p / (1 - raw_p)).reshape(-1, 1)
    calibrated_p = bundle["calibrator"].predict_proba(logits)[:, 1]

    out = input_df.copy()
    out["backsliding_risk"] = calibrated_p
    out["predicted_backslide_5pp"] = (
        calibrated_p >= bundle["classification_threshold"]
    ).astype(int)
    return out
