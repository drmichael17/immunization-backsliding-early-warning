Final CatBoost Childhood Immunization Backsliding Model

Primary file:
  final_catboost_backsliding_model.joblib

Model:
  CatBoost, WUENIC + one-year-lagged World Bank predictors

Outcome:
  Next-year DTP3 decline >=5 percentage points

Locked training period:
  Predictor years 2002-2018

Held-out evaluation:
  COVID stress test 2019-2020
  Final post-COVID test 2021-2024

Calibrated classification threshold:
  0.120810059042976

Important:
  This is the locked evaluation model corresponding to the reported study results.
  The 2021-2024 test data were not used to fit this model.
  It is a research prediction model and has not undergone prospective deployment validation.
