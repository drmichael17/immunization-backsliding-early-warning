# Predicting Childhood Immunization Backsliding Before It Occurs

Reproducibility materials for the study **“Predicting Childhood Immunization Backsliding Before It Occurs: A Global Machine-Learning Early-Warning Study Across 195 Countries.”**

## Study summary

This repository contains the derived analytical datasets, locked CatBoost evaluation model, data dictionary, key result files, publication figures, and scripts used to construct the core WUENIC and World Bank portions of the analytical dataset and to verify the reported final-test results.

The primary outcome is **next-year DTP3 backsliding**, defined as a decline of at least **5 percentage points** in DTP3 coverage between predictor year *t* and outcome year *t+1*.

Primary analytical sample:
- 195 countries
- 4,466 country-year observations
- Predictor years 2002–2024
- 379 primary backsliding events
- Development: 2002–2018
- COVID-19 stress test: 2019–2020
- Final post-COVID test: 2021–2024

## Repository contents

```text
data/
  PRIMARY_Model_Dataset_WUENIC_WDI_2002_2024.csv
  DATA_DICTIONARY.csv
  secondary/
    SECONDARY_Finance_Enhanced_2003_2024.csv
    SECONDARY_DTP_Supply_Enhanced_2012_2023.csv
    SECONDARY_System_Performance_Enhanced_2019_2024.csv
    SECONDARY_Full_Operational_2019_2023.csv
model/
  final_catboost_backsliding_model.joblib
  catboost_locked_evaluation_model.cbm
  catboost_locked_evaluation_model.json
  imputer.joblib
  platt_calibrator.joblib
  model_metadata.json
  example_inference.py
src/
  build_wuenic_core_dataset.py
  merge_world_bank_predictors.py
  verify_reported_results.py
results/
  champion_catboost_calibrated_metrics.csv
  champion_catboost_predictions.csv
  final_raw_temporal_comparison.csv
  tuning_only.csv
  wdi_incremental_value_postcovid.csv
figures/
  Figure_1_Annual_Backsliding_Prevalence.png
  Figure_2_Global_Risk_Map_2024.png
  Figure_3_Model_Comparison_AUPRC.png
  Figure_4_Risk_Concentration_Curve.png
  Figure_5_SHAP_Global_Importance.png
  Figure_6_JRF_Incremental_AUROC.png
```

## Data sources

The source data are publicly available from:

1. **WHO/UNICEF Estimates of National Immunization Coverage (WUENIC), 2025 revision**  
   https://www.who.int/publications/m/item/WUENIC_notes
2. **World Bank World Development Indicators (WDI)**  
   https://datatopics.worldbank.org/world-development-indicators/
3. **WHO/UNICEF Joint Reporting Process / JRF**  
   https://www.who.int/teams/immunization-vaccines-and-biologicals/Immunization-data-and-decision-making/global-monitoring/who-unicef-joint-reporting-process

This repository provides **derived analytical datasets**, not copies of all original provider workbooks. Users should consult and comply with the source providers' current terms of use and attribution requirements.

## Primary model

The locked evaluation model is a CatBoost model using WUENIC immunization trajectory features plus seven one-year-lagged World Bank predictors.

The model was trained on predictor years **2002–2018**. The 2019–2020 period was reserved as a COVID-era stress test, and 2021–2024 was retained as the final post-COVID temporal test set.

Probability calibration used Platt scaling fitted on rolling-origin out-of-fold development predictions. The locked classification threshold is **0.1208100590429761**.

The model is intended for **research and risk prioritization**, not autonomous programme or clinical decision-making. It has not undergone prospective deployment validation.

## Reproduce the locked final-test metrics

Create an environment and install the pinned dependencies:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

Then run:

```bash
python src/verify_reported_results.py
```

The script uses the locked model artifact and the derived analytical dataset to reproduce the reported 2021–2024 final-test discrimination, calibration, threshold, and risk-concentration metrics.

Expected values are approximately:
- AUROC: 0.7028
- AUPRC: 0.2073
- Brier score: 0.0728
- Sensitivity: 0.5231
- Specificity: 0.7357
- Precision: 0.1525
- F1: 0.2361
- Event capture in highest-risk 10%: 0.2923
- Event capture in highest-risk 20%: 0.3692

## Notes on full data reconstruction

`src/build_wuenic_core_dataset.py` and `src/merge_world_bank_predictors.py` document the core WUENIC and World Bank data-building workflow. JRF-derived secondary analytical datasets are provided directly in `data/secondary/` because historical JRF exports changed schema across periods and required domain-specific harmonization.

## Citation

Please cite the associated manuscript when using these materials. A `CITATION.cff` file is included and should be updated with the final journal citation and repository URL after publication.

## License and source terms

No repository-wide license is asserted here. The source datasets remain subject to the terms of their respective providers. Before public release, the authors should select an explicit license for original code and derived materials that is compatible with those source terms.
